-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th9 11, 2022 lúc 08:21 PM
-- Phiên bản máy phục vụ: 10.4.24-MariaDB
-- Phiên bản PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `db_web`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_muc`
--

CREATE TABLE `danh_muc` (
  `id` int(11) NOT NULL,
  `ma_dm` varchar(50) NOT NULL,
  `ten_dm` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `danh_muc`
--

INSERT INTO `danh_muc` (`id`, `ma_dm`, `ten_dm`) VALUES
(1, 'DT', 'Điện thoại'),
(2, 'PK', 'Phụ kiện'),
(3, 'TB', 'Tablet'),
(4, 'áđ', 'xfxf');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dh_tinh_trang`
--

CREATE TABLE `dh_tinh_trang` (
  `id` int(11) NOT NULL,
  `mo_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `dh_tinh_trang`
--

INSERT INTO `dh_tinh_trang` (`id`, `mo_ta`) VALUES
(1, 'Đang xử lý'),
(2, 'Đã đóng gói'),
(3, 'Đang vận chuyển'),
(4, 'Đã giao hàng'),
(5, 'Trả lại hàng'),
(6, 'Hủy đơn');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `don_hang`
--

CREATE TABLE `don_hang` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `ma_dh` text NOT NULL,
  `id_loai` int(11) NOT NULL,
  `ma_sp` varchar(50) NOT NULL,
  `ten_sp` varchar(100) NOT NULL,
  `loai` text NOT NULL,
  `mau` varchar(100) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `gia` int(11) NOT NULL,
  `thanh_tien` int(11) NOT NULL,
  `ho_ten` varchar(100) NOT NULL,
  `sdt` int(11) NOT NULL,
  `dia_chi` varchar(200) NOT NULL,
  `yeu_cau` varchar(2500) NOT NULL,
  `id_tinh_trang` int(11) NOT NULL DEFAULT 1,
  `thoi_gian_dh` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `don_hang`
--

INSERT INTO `don_hang` (`id`, `id_user`, `ma_dh`, `id_loai`, `ma_sp`, `ten_sp`, `loai`, `mau`, `so_luong`, `gia`, `thanh_tien`, `ho_ten`, `sdt`, `dia_chi`, `yeu_cau`, `id_tinh_trang`, `thoi_gian_dh`) VALUES
(1, 11, ' 20220717074418', 12, 'xmm4', 'xiaomi mix 4', '1', 'Màu trắng', 1, 67, 67, 'hfgsdf', 65204545, 'fa fadf', 'zxc', 6, '2022-07-17 12:54:07'),
(2, 11, ' 20220717075556', 16, 'SS-S22ULTRA-5G', 'Samsung Galaxy s22 Ultra 5g', '3', 'Tim', 3, 56, 168, 'hfgsdf 4f', 2147483647, 'fa fadf 33 ', 'khong ', 4, '2022-07-17 12:56:15'),
(3, 11, ' 20220717075556', 18, 'xmm4', 'xiaomi mix 4', '4', 'Màu đen', 2, 34, 68, 'hfgsdf 4f', 2147483647, 'fa fadf 33 ', 'khong ', 1, '2022-07-17 12:56:15'),
(4, 11, ' 20220717081657', 12, 'xmm4', 'xiaomi mix 4', '1', 'Màu trắng', 2, 67, 134, 'hfgsdf 4f', 2147483647, 'fa fadf 33 ', '', 5, '2022-07-17 13:16:59'),
(6, 11, ' 20220907184918', 20, 'SSGLX-S9', 'Samsung Galaxy s9pr', '1', 'Màu đen', 1, 35, 35, 'hfgsdf 4f', 2147483647, 'fa fadf 33 ', '', 1, '2022-09-07 23:49:21'),
(7, 11, ' 20220910074134', 20, 'SSGLX-S9', 'Samsung Galaxy s9pr', '1', 'Màu đen', 2, 35, 70, 'hfgsdf 4f', 2147483647, 'fa fadf 33 ', '', 1, '2022-09-10 12:41:40');

--
-- Bẫy `don_hang`
--
DELIMITER $$
CREATE TRIGGER `update_sl_sp` AFTER INSERT ON `don_hang` FOR EACH ROW UPDATE sp_loai SET 
so_luong = (SELECT so_luong FROM sp_loai WHERE id = new.id_loai) - new.so_luong,
da_ban = (SELECT da_ban FROM sp_loai WHERE id = new.id_loai) + new.so_luong
WHERE 
sp_loai.id = new.id_loai
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `kho`
--

CREATE TABLE `kho` (
  `id` int(11) NOT NULL,
  `id_loai` int(11) NOT NULL,
  `so_luong_nhap` int(11) DEFAULT NULL,
  `ngay_nhap` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `san_pham`
--

CREATE TABLE `san_pham` (
  `id` int(11) NOT NULL,
  `ma_sp` varchar(50) NOT NULL,
  `ten_sp` varchar(100) NOT NULL,
  `id_dm` int(11) NOT NULL,
  `id_th` int(11) NOT NULL,
  `diem_danh_gia` int(11) NOT NULL,
  `mo_ta_ngan` varchar(2500) NOT NULL,
  `mo_ta` varchar(10000) NOT NULL,
  `ngay_nhap` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `san_pham`
--

INSERT INTO `san_pham` (`id`, `ma_sp`, `ten_sp`, `id_dm`, `id_th`, `diem_danh_gia`, `mo_ta_ngan`, `mo_ta`, `ngay_nhap`) VALUES
(34, 'xmm4', 'xiaomi mix 4', 1, 4, 2, '<div class=\"product-info-content\">\r\n		<table>\r\n			<tbody>\r\n				<tr>\r\n					<td>Màn hình:</td>\r\n					<td>AMOLED, 1B colors, 120Hz, HDR10+, Dolby Vision<br>\r\n6.67 inches, 107.4 cm2 (~87.6%)<br>\r\nFull HD+, 1080 x 2400 pixels, 20:9 (~395 ppi)<br>\r\nCorning Gorilla Glass Victus<br>\r\nVân tay trên màn hình.<br>\r\nCamera ẩn siêu nét.</td>\r\n				</tr>\r\n				<tr>\r\n					<td>Hệ điều hành:</td>\r\n					<td>Android 11, MIUI 12.5</td>\r\n				</tr>\r\n				<tr>\r\n					<td>Camera sau:</td>\r\n					<td>108 MP, f/1.9, 24mm (góc rộng), PDAF, OIS<br>\r\n8 MP, f/4.1, 120mm (tiềm vọng), PDAF, OIS, 50x zoom<br>\r\n13 MP, f/2.4, 12mm, 123˚ (siêu rộng)<br>\r\nDual-LED flash, HDR, panorama<br>\r\nQuay video: 8K@24/30fps, 4K@30/60fps, 1080p@30/60/120/240fps; gyro-EIS, HDR10+</td>\r\n				</tr>\r\n				<tr>\r\n					<td>Camera trước:</td>\r\n					<td>Camera ẩn 20 MP<br>\r\nQuay phim: 1080p@30fps, 720p@120fps, 960fps</td>\r\n				</tr>\r\n				<tr>\r\n					<td>CPU:</td>\r\n					<td>Qualcomm SM8350 Snapdragon 888 Plus 5G (5 nm)</td>\r\n				</tr>\r\n				<tr>\r\n					<td>RAM:</td>\r\n					<td>8-12GB</td>\r\n				</tr>\r\n				<tr>\r\n					<td>Bộ nhớ trong:</td>\r\n					<td>128-256GB UFS 3.1</td>\r\n				</tr>\r\n				<tr>\r\n					<td>Thẻ SIM:</td>\r\n					<td>2 SIM</td>\r\n				</tr>\r\n				<tr>\r\n					<td>Dung lượng pin:</td>\r\n					<td>4500 mAh <br>\r\nSạc nhanh 120W, 100% trong 15ph<br>\r\nSạc không dây 50W, 100% trong 28ph (quảng cáo)</td>\r\n				</tr>\r\n				<tr>\r\n					<td>Thiết kế:</td>\r\n					<td>Màn hình phẳng tuyệt đối</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		\r\n	</div>', '<div class=\"product-detail-content css-content more-height\" style=\"height: auto;\">\n	                        	<p>Xiaomi Mi Mix 4 siêu mạnh: Snap 888+, Camera ẩn, giá siêu hợp lý tại Hà Nội, Đà Nẵng, Tp.HCM. <strong>Xiaomi Mi Mix 4</strong> BH 12 tháng chính hãng!</p>\n<p>Mi MIX 4 sẽ có màn hình OLED 6.67 inch với các cạnh cong. Màn hình sẽ hỗ trợ độ phân giải Full HD+ (1.080 x 2.340 pixel), mật độ điểm ảnh 386 PPI và tốc độ làm mới 120Hz. Thông số kỹ thuật chính của <a title=\"Xiaomi Mi MIX 4\" href=\"https://mobilecity.vn/xiaomi/xiaomi-mi-mix-4.html\" target=\"_blank\" rel=\"noopener noreferrer\">Xiaomi Mi MIX 4</a> đã bị rò rỉ trên Weibo. Nguồn: Gizmochina. Bên trong, Mi MIX 4 sẽ được trang bị bộ vi xử lý Snapdragon 888 Plus, có 12 GB LPDDR5 RAM và bộ nhớ lưu trữ lên đến 1 TB chuẩn UFS 3.1. Đồng thời thiết bị sẽ sở hữu một viên pin 5.000 mAh, hỗ trợ sạc nhanh có dây 120W và sạc nhanh không dây 80W.</p>\n<figure class=\"sudo-media-item\"><img class=\"lazy\" src=\"https://cdn.mobilecity.vn/mobilecity-vn/images/2021/08/xiaomi-mi-mix-4-1.jpeg\" data-original=\"https://cdn.mobilecity.vn/mobilecity-vn/images/2021/08/xiaomi-mi-mix-4-1.jpeg\" alt=\"\" style=\"\">\n<figcaption>Xiaomi Mi Mix 4</figcaption>\n</figure>\n<p>&nbsp;</p>\n<figure class=\"sudo-media-item\"><img class=\"lazy\" src=\"https://cdn.mobilecity.vn/mobilecity-vn/images/2021/08/xiaomi-mi-mix-4-2.jpeg\" data-original=\"https://cdn.mobilecity.vn/mobilecity-vn/images/2021/08/xiaomi-mi-mix-4-2.jpeg\" alt=\"\" style=\"\">\n<figcaption>Xiaomi Mi Mix 4</figcaption>\n</figure>\n<p>&nbsp;</p>\n							</div>', '2022-06-27'),
(37, 'SSGLX-S', 'Samsung Galaxy s9', 1, 3, 3, '', 'Người ta nói cái gì không bể thì đừng có vá, điều này rất đúng khi nói đến chiếc S9. Nó không tìm cách thay đổi cái gì đã hoàn hảo, chỉ chỉnh sửa lại cấu hình ở bất kì chỗ nào có thể - và kết quả là rất tuyệt vời.\nChiếc điện thoại Samsung mới này vẫn đi theo triết lí thiết kế tương tự như Galaxy S8 với khung viền kim loại cứng cáp cùng mặt lưng kính bóng bẩy bo cong mềm mại. Đặc biệt, phần khung viền của Galaxy S9 được hoàn thiện bằng kim loại nhám giúp cầm nắm chắc tay tốt hơn hẳn, chứ không bóng loáng như thời S8. \nGalaxy S9 có kích thước màn hình vô cực tỉ lệ 18.5:9, giữ nguyên so với người tiền nhiệm, cụ thể là 5.8 inch. Sử dụng tấm nền Super AMOLED như truyền thống trước giờ của các flagship Samsung, độ phân giải 2K+ đi cùng công nghệ hiển thị HDR 10 ấn tượng.\nS9 sử dụng bộ chip set mới: Exynos 9810 với tốc độ cao hơn 20% so với con chip Exynos 8895 mà S8 sử dụng. Nhưng mà điểm Samsung đã đẩy mạnh nhất là về camera. Với khẩu độ có thể thay đổi từ f/1.5 đến f/2.4, bây giờ chiếc Galaxy S9 có thể thống soái vai trò chụp ảnh ngay cả trong môi trường thiếu sáng hoặc thừa sáng. Máy còn đi kèm chức năng quay phim 4K 60fps và quay phim siêu chậm 960fps và định vị chuyển động tự động.\nS9 cũng mang theo nhiều thay đổi nhỏ mà người dùng không nhận ra khi cầm trên, nhưng mọi người đều sẽ nhận ra và yêu thích chúng khi họ bắt đầu sử dụng máy. Cặp loa stereo được tinh chỉnh bởi Harman - lần đầu tiên trong lineup của Galaxy S - cho máy khả năng phát âm thanh chân thực với sự hỗ trợ của Dolby Atmos. Sự kết hợp giữa hệ thống khóa máy bằng vân tay, dịnh dạng mặt, và nhận dạng con ngươi là một sự kết hợp mạnh mẽ mà dường như là điều nên có trên mọi chiếc điện thoại tiên tiến.', '2022-06-27'),
(38, 'SSGLX-S9', 'Samsung Galaxy s9pr', 1, 3, 3, '', '', '2022-06-27'),
(39, 'MOPHIE-PD-18W-C', 'Củ sạc mophie Power Delivery 18W usb-c', 2, 2, 4, '', 'Sạc Mophie Power Delivery 18W USB-C – Phụ kiện sạc nhanh chính hãng\r\nHiện nay, để tối ưu hóa tốc độ sạc cũng như thay đổi chuẩn để phù hợp với công nghệ sạc trên thiết bị hầu hết các hãng sản xuất sạc đều dần đổi sang sử dụng chuẩn USB-C. Thiết bị của bạn đang sử dụng USB-C và bạn đang tìm kiếm mua cho mình một bộ cáp sạc vừa phù hợp với jack dây sạc vừa phù hợp với chiếc điện thoại để không gây ảnh hưởng tốc độ sạc. Sạc Mophie Power Delivery 18W USB-C là sự lựa chọn hoàn hảo cho bạn cả về tốc độ cũng như độ an toàn.\r\nThiết kế nhỏ gọn, chất liệu nhựa nhám chống bám bụi bẩn, bền bỉ\r\nSạc Mophie Power Delivery 18W USB-C với thiết kế rất nhỏ gọn, chiếm diện tích không đáng kể khi cắm vào ổ điện, dễ dàng gắn cùng các đầu cắm điện khác trên cùng bản điện. Không những vậy sạc còn rất thuận tiện để vào túi xách mang đi ra ngoài với khối lượng chỉ 50g. Tuy kích thước nhỏ và khối lượng không đáng kể nhưng sạc Mophie Power Delivery 18W sẽ làm bạn ngạc nhiên với tốc độ của nó.\r\nHãng sản xuất đã thiết kế cho sạc Mophie Power Delivery 18W USB-C sử dụng chất liệu nhựa nhám tổng hợp cao cấp hạn chế nứt vỡ khi va đập. Lớp sơn đen nhám được bao phủ bên ngoài sản phẩm tạo nên sự sang trọng và tinh tế cho bộ sạc. Hơn thế nữa, lớp vỏ đen nhám có tính năng chống bám vân tay và mồ hôi giúp cho sạc của bạn luôn sạch sẽ mọi lúc.\r\nTrang bị công nghệ sạc nhanh công suất 18W, ổn định dòng điện khi sạc\r\nSạc Mophie Power Delivery 18W USB-C có công suất sạc lên đến 18W hỗ trợ sạc nhanh mọi thiết bị sử dụng cổng USB-C Power Delivery giúp thiết bị của bạn đầy pin nhanh chóng, giảm thời gian chờ đợi khi sạc. Với công suất sạc lên đến 18W bạn hoàn toàn có thể tự tin sử dụng từ các dòng điện thoại cao cấp đến thấp hơn đều được sạc đầy pin nhanh đáng kể mà không ảnh hưởng đến pin của thiết bị.\r\nSạc Mophie Power Delivery 18W USB-C có điện áp đầu ra và đầu vào ổn định giúp cho cường độ dòng điện được truyền luôn giữ được đúng định mức và xuyên suốt trong quá trình sạc. Khi sạc thiết bị của bạn sẽ không bị quá tải và nóng tối ưu tốt thời gian sạc cũng như tuổi thọ của viên pin.\r\nTương thích nhiều thiết bị hiện nay, đạt chuẩn an toàn chống cháy nổ\r\nSạc Mophie Power Delivery 18W USB-C với điện áp chuẩn đầu ra lần lượt 5V-3A, 9V-2A, 12V-1.5A phù hợp hầu hết các điện thoại, máy tính bảng hiện nay. Khi bạn mua sạc Mophie Power Delivery 18W 1 USB-C, bạn sẽ không cần phải lo nghĩ đến việc sạc có phù hợp với thiết bị của mình hay không sạc sẽ tự điều chỉnh mức chuẩn đầu ra phù hợp với thiết bị không ảnh hưởng đến pin của thiết bị.\r\nKhi bạn chọn mua sạc điều bạn quan tâm là độ an toàn của nó có đạt các tiêu chuẩn về an toàn chống cháy nổ hay không. Đối với sạc Mophie Power Delivery 18W USB-C bạn hoàn toàn có thể yên tâm sử dụng về độ an toàn của nó. Sạc Mophie Power Delivery 18W đã trải qua các vòng thử nghiệm khắt khe và đạt các tiêu chuẩn an toàn về cháy nổ toàn cầu.\r\nMua sạc Mophie Power Delivery 18W USB-C giá rẻ, chính hãng tại Dat-G mobie\r\nVới những tính năng tuyệt vời mang đến cho người sử dụng, sạc Mophie Power Delivery 18W USB-C chính hãng sẽ là sự lựa chọn hoàn hảo về tốc độ cũng như vẻ ngoài đen nhám sang trọng cho bạn. Phụ kiện được bán với giá ưu đãi cùng chính sách bảo hành cực tốt. Dat-G mobie xứng đáng là nơi để quý khách hàng tin tưởng lựa chọn mua sạc Mophie Power Delivery 18W 1 USB-C. Khi mua sạc Mophie 18W chính hãng tại đây bạn sẽ được bảo hành 24 tháng chính hãng.', '2022-06-27'),
(40, 'SS-S22ULTRA-5G', 'Samsung Galaxy s22 Ultra 5g', 1, 3, 4, '', '', '2022-06-27'),
(57, 'IPHONE-14-PRO-MAX', 'iPhone 14 Pro Max', 1, 1, 0, ' Màn hình\r\nOLED6.7\"Super Retina XDR\r\nHệ điều hành\r\niOS 16\r\nCamera sau\r\nChính 48 MP & Phụ 12 MP, 12 MP\r\nCamera trước\r\n12 MP\r\nChip\r\nApple A16 Bionic 6 nhân\r\nBộ nhớ trong\r\n128 GB, 256 GB, 512 GB, 1 TB', '', '2022-09-12');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `url` text NOT NULL,
  `tieu_de` varchar(500) NOT NULL,
  `mo_ta` varchar(2000) NOT NULL,
  `anh` text NOT NULL,
  `tinh_trang` int(11) NOT NULL,
  `vi_tri` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `slider`
--

INSERT INTO `slider` (`id`, `url`, `tieu_de`, `mo_ta`, `anh`, `tinh_trang`, `vi_tri`) VALUES
(14, '?', 'k', '0', '1651484944s22.png', 0, 0),
(15, '?', 'n', '0', '1651485202Nokia_G21.png', 0, 0),
(16, '?', 'i', '0', '1651485213ip13-xl-sh-690-300-max.png', 0, 0),
(17, '?ctrl=Product_List&act=sp&dm=2&th=2', 'Phụ kiện', 'Các loại phụ kiện', '1660374743huawei.jpg', 0, 1),
(18, '?ctrl=Product_List&act=sp&dm=1&th=1', 'iphone', 'Tất cả sản phẩm iphone', '1660374946appleDT-390x210-1.png', 0, 1),
(19, '?ctrl=Product_List&act=sp&dm=1&th=3', 'Samsung', 'Tất cả sản phẩm của samsung', '1660375241samsung-390-210-390x210.png', 0, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sp_danh_gia`
--

CREATE TABLE `sp_danh_gia` (
  `id` int(11) NOT NULL,
  `id_sp` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `diem_danh_gia` int(11) NOT NULL,
  `noi_dung` varchar(10000) NOT NULL,
  `thoi_gian` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `sp_danh_gia`
--

INSERT INTO `sp_danh_gia` (`id`, `id_sp`, `id_user`, `diem_danh_gia`, `noi_dung`, `thoi_gian`) VALUES
(1, 34, 11, 1, 'áđâsf', '2022-09-11 14:55:29'),
(2, 34, 11, 1, 'áđâsf', '2022-09-11 14:55:29'),
(3, 34, 11, 5, 'áđâsf', '2022-09-11 14:55:29');

--
-- Bẫy `sp_danh_gia`
--
DELIMITER $$
CREATE TRIGGER `update_rate` AFTER INSERT ON `sp_danh_gia` FOR EACH ROW UPDATE san_pham SET 
san_pham.diem_danh_gia = 
(SELECT SUM(sp_danh_gia.diem_danh_gia) FROM sp_danh_gia WHERE sp_danh_gia.id_sp = new.id_sp)/
(SELECT COUNT(sp_danh_gia.diem_danh_gia) FROM sp_danh_gia WHERE sp_danh_gia.id_sp = new.id_sp)

WHERE san_pham.id = new.id_sp
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sp_image`
--

CREATE TABLE `sp_image` (
  `id` int(11) NOT NULL,
  `ma_sp` varchar(50) NOT NULL,
  `anh` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `sp_image`
--

INSERT INTO `sp_image` (`id`, `ma_sp`, `anh`) VALUES
(23, 'SSGLX-S9', '1651222805samsung-galaxy-s9.png'),
(26, 'SSGLX-S', '1651222805samsung-galaxy-s9.png'),
(27, 'SS-S22ULTRA-5G', '1650966562samsung-galaxy-note-20-ultra.jpg'),
(28, 'xmm4', '1650884436Xiaomi-Mi-Mix-4.jpg'),
(29, 'MOPHIE-PD-18W-C', '1651482485cu-sac-mophie-pd-18w-usb-c.png'),
(35, 'IPHONE-14-PRO-MAX', '166291988414pro-tim-600x600-7.png'),
(36, 'IPHONE-14-PRO-MAX', '1662919884iphone-14-pro-max-080922-101659.jpg'),
(37, 'IPHONE-14-PRO-MAX', '1662919884iphone-14-pro-max-080922-101711.jpg'),
(38, 'IPHONE-14-PRO-MAX', '1662919884iphone-14-pro-max-080922-101705.jpg'),
(39, 'IPHONE-14-PRO-MAX', '1662919884iphone-14-pro-max-080922-101709.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sp_loai`
--

CREATE TABLE `sp_loai` (
  `id` int(11) NOT NULL,
  `ma_sp` varchar(50) NOT NULL,
  `loai` text NOT NULL,
  `ma_mau` text NOT NULL,
  `ten_mau` varchar(100) NOT NULL,
  `gia` int(11) NOT NULL,
  `gia_giam` int(11) NOT NULL DEFAULT 0,
  `so_luong` int(11) NOT NULL,
  `da_ban` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `sp_loai`
--

INSERT INTO `sp_loai` (`id`, `ma_sp`, `loai`, `ma_mau`, `ten_mau`, `gia`, `gia_giam`, `so_luong`, `da_ban`) VALUES
(12, 'xmm4', '1', '#fff', 'Màu trắng', 67, 60, 2, 2),
(13, 'xmm4', '1', '#000', 'Màu đen', 0, 0, 15, 0),
(14, 'SSGLX-S', '2', '#935cad', 'Tim', 33, 0, 1, 0),
(15, 'SSGLX-S', '2', '#5295cc', 'Xanh', 213, 0, 2, 0),
(16, 'SS-S22ULTRA-5G', '3', '#935cad', 'Tim', 56, 0, 2, 0),
(17, 'SS-S22ULTRA-5G', '3', '#000', 'Màu đen', 123, 0, 0, 1),
(18, 'xmm4', '4', '#000', 'Màu đen', 34, 0, 3, 0),
(19, 'MOPHIE-PD-18W-C', '2', '#000', 'Màu đen', 76, 0, 15, 0),
(20, 'SSGLX-S9', '1', '#000', 'Màu đen', 35, 0, 12, 3),
(27, 'IPHONE-14-PRO-MAX', '128 GB', '#9106b7', 'Màu tím', 33990000, 0, 50, 0),
(28, 'IPHONE-14-PRO-MAX', '128 GB', '#ffea00', 'Màu Vàng', 33990000, 0, 50, 0),
(29, 'IPHONE-14-PRO-MAX', '128 GB', '#c7c7c7', 'Màu bạc', 33990000, 0, 50, 0),
(30, 'IPHONE-14-PRO-MAX', '128 GB', '#000000', 'Màu đen', 33990000, 0, 50, 0),
(31, 'IPHONE-14-PRO-MAX', '256 GB', '#7e00c2', 'Màu tím', 36990000, 0, 50, 0),
(32, 'IPHONE-14-PRO-MAX', '256 GB', '#e1ff00', 'Màu Vàng', 36990000, 0, 50, 0),
(33, 'IPHONE-14-PRO-MAX', '256 GB', '#b8b8b8', 'Màu bạc', 36990000, 0, 50, 0),
(34, 'IPHONE-14-PRO-MAX', '256 GB', '#000000', 'Màu đen', 36990000, 0, 50, 0);

-- --------------------------------------------------------

--
-- Cấu trúc đóng vai cho view `sp_view`
-- (See below for the actual view)
--
CREATE TABLE `sp_view` (
`id` int(11)
,`ma_sp` varchar(50)
,`ten_sp` varchar(100)
,`id_dm` int(11)
,`id_th` int(11)
,`diem_danh_gia` int(11)
,`mo_ta_ngan` varchar(2500)
,`mo_ta` varchar(10000)
,`ngay_nhap` date
,`id_loai` int(11)
,`loai` text
,`ma_mau` text
,`ten_mau` varchar(100)
,`so_luong` int(11)
,`da_ban` int(11)
,`gia` int(11)
,`gia_giam` int(11)
,`anh` text
);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `ho_ten` varchar(50) NOT NULL,
  `gioi_tinh` varchar(10) NOT NULL,
  `ngay_sinh` date NOT NULL,
  `email` varchar(150) NOT NULL,
  `sdt` int(11) NOT NULL,
  `dia_chi` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `anh` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `ho_ten`, `gioi_tinh`, `ngay_sinh`, `email`, `sdt`, `dia_chi`, `password`, `anh`) VALUES
(1, 'nguyen hien', 'Nam', '2000-09-08', 'hien@gmail.com', 865198651, 'a', 'e10adc3949ba59abbe56e057f20f883e', '1656841826Avatar.jpg'),
(11, 'fun', 'Nam', '2022-09-01', '123456789', 0, 'ninh binh', 'e10adc3949ba59abbe56e057f20f883e', '1662801578Avatar.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_contact`
--

CREATE TABLE `tb_contact` (
  `id` int(11) NOT NULL,
  `ho_ten` varchar(100) NOT NULL,
  `email` text NOT NULL,
  `sdt` int(11) NOT NULL,
  `noi_dung` varchar(2500) NOT NULL,
  `seen` int(11) NOT NULL DEFAULT 0,
  `thoi_gian` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tb_contact`
--

INSERT INTO `tb_contact` (`id`, `ho_ten`, `email`, `sdt`, `noi_dung`, `seen`, `thoi_gian`) VALUES
(1, 'zxczv', 'zxc@gmail.com', 12324, 'chả có gì cả để mà xem đâu', 0, '2022-07-19 20:56:56'),
(2, 'zxczv', 'zxc@gmail.com', 12324, 'zxcvcxvb xcvbcvb', 0, '2022-07-19 20:55:56');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tb_users`
--

CREATE TABLE `tb_users` (
  `id` int(11) NOT NULL,
  `ho_ten` varchar(50) NOT NULL,
  `gioi_tinh` varchar(10) NOT NULL,
  `ngay_sinh` date NOT NULL,
  `sdt` int(12) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `dia_chi` varchar(150) NOT NULL,
  `anh` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `tb_users`
--

INSERT INTO `tb_users` (`id`, `ho_ten`, `gioi_tinh`, `ngay_sinh`, `sdt`, `email`, `password`, `dia_chi`, `anh`) VALUES
(3, 'hien vca', 'Khác', '2000-09-09', 2147483647, 'fsdf@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'bac ninh a', '1662800455Avatar.jpg'),
(11, 'hfgsdf 4fấ1', 'Nam', '2022-04-15', 2147483647, 'a@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'fa fadf 33 sd1', '1662790039Avatar.jpg'),
(12, 'fun 123', 'Nữ', '2022-08-13', 2147483647, 'fun123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ninh binh ád', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thuong_hieu`
--

CREATE TABLE `thuong_hieu` (
  `id` int(11) NOT NULL,
  `id_dm` int(11) NOT NULL,
  `ma_th` varchar(50) NOT NULL,
  `ten_th` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `thuong_hieu`
--

INSERT INTO `thuong_hieu` (`id`, `id_dm`, `ma_th`, `ten_th`) VALUES
(1, 1, 'IP', 'Iphone'),
(2, 2, 'MP', 'Mophie '),
(3, 1, 'SS', 'SamSung'),
(4, 1, 'XM', 'Xiaomi'),
(5, 3, 'ccz', 'ca cappp');

-- --------------------------------------------------------

--
-- Cấu trúc đóng vai cho view `view_danh_gia`
-- (See below for the actual view)
--
CREATE TABLE `view_danh_gia` (
`id` int(11)
,`id_user` int(11)
,`id_sp` int(11)
,`ma_sp` varchar(50)
,`ho_ten` varchar(50)
,`diem_danh_gia` int(11)
,`noi_dung` varchar(10000)
,`thoi_gian` datetime
);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `yeu_thich`
--

CREATE TABLE `yeu_thich` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_sp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc cho view `sp_view`
--
DROP TABLE IF EXISTS `sp_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view`  AS SELECT `sp`.`id` AS `id`, `sp`.`ma_sp` AS `ma_sp`, `sp`.`ten_sp` AS `ten_sp`, `sp`.`id_dm` AS `id_dm`, `sp`.`id_th` AS `id_th`, `sp`.`diem_danh_gia` AS `diem_danh_gia`, `sp`.`mo_ta_ngan` AS `mo_ta_ngan`, `sp`.`mo_ta` AS `mo_ta`, `sp`.`ngay_nhap` AS `ngay_nhap`, `sp_l`.`id` AS `id_loai`, `sp_l`.`loai` AS `loai`, `sp_l`.`ma_mau` AS `ma_mau`, `sp_l`.`ten_mau` AS `ten_mau`, `sp_l`.`so_luong` AS `so_luong`, `sp_l`.`da_ban` AS `da_ban`, `sp_l`.`gia` AS `gia`, `sp_l`.`gia_giam` AS `gia_giam`, `sp_img`.`anh` AS `anh` FROM ((`san_pham` `sp` left join `sp_loai` `sp_l` on(`sp`.`ma_sp` = `sp_l`.`ma_sp`)) left join `sp_image` `sp_img` on(`sp`.`ma_sp` = `sp_img`.`ma_sp`)) ORDER BY `sp`.`id` AS `DESCdesc` ASC  ;

-- --------------------------------------------------------

--
-- Cấu trúc cho view `view_danh_gia`
--
DROP TABLE IF EXISTS `view_danh_gia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_danh_gia`  AS SELECT `sp_dg`.`id` AS `id`, `sp_dg`.`id_user` AS `id_user`, `sp_dg`.`id_sp` AS `id_sp`, `sp`.`ma_sp` AS `ma_sp`, `usr`.`ho_ten` AS `ho_ten`, `sp_dg`.`diem_danh_gia` AS `diem_danh_gia`, `sp_dg`.`noi_dung` AS `noi_dung`, `sp_dg`.`thoi_gian` AS `thoi_gian` FROM ((`san_pham` `sp` left join `sp_danh_gia` `sp_dg` on(`sp`.`id` = `sp_dg`.`id_sp`)) left join `tb_users` `usr` on(`usr`.`id` = `sp_dg`.`id_user`)) ORDER BY `sp_dg`.`thoi_gian` AS `DESCdesc` ASC  ;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `danh_muc`
--
ALTER TABLE `danh_muc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ma_dm` (`ma_dm`);

--
-- Chỉ mục cho bảng `dh_tinh_trang`
--
ALTER TABLE `dh_tinh_trang`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `don_hang`
--
ALTER TABLE `don_hang`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id_User` (`id_user`),
  ADD KEY `id_Tinh_Trang` (`id_tinh_trang`);

--
-- Chỉ mục cho bảng `kho`
--
ALTER TABLE `kho`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id_loai` (`id_loai`);

--
-- Chỉ mục cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Ma_DM` (`id_dm`,`id_th`),
  ADD KEY `Ma_TH` (`id_th`),
  ADD KEY `id_th` (`id_th`),
  ADD KEY `Ma_SP` (`ma_sp`) USING BTREE;

--
-- Chỉ mục cho bảng `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `sp_danh_gia`
--
ALTER TABLE `sp_danh_gia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_sp` (`id_sp`);

--
-- Chỉ mục cho bảng `sp_image`
--
ALTER TABLE `sp_image`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ma_sp` (`ma_sp`);

--
-- Chỉ mục cho bảng `sp_loai`
--
ALTER TABLE `sp_loai`
  ADD PRIMARY KEY (`id`),
  ADD KEY `san_phan_loai` (`ma_sp`);

--
-- Chỉ mục cho bảng `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_contact`
--
ALTER TABLE `tb_contact`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `thuong_hieu`
--
ALTER TABLE `thuong_hieu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ma_th` (`ma_th`);

--
-- Chỉ mục cho bảng `yeu_thich`
--
ALTER TABLE `yeu_thich`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_sp` (`id_sp`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `danh_muc`
--
ALTER TABLE `danh_muc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT cho bảng `dh_tinh_trang`
--
ALTER TABLE `dh_tinh_trang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `don_hang`
--
ALTER TABLE `don_hang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT cho bảng `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT cho bảng `sp_danh_gia`
--
ALTER TABLE `sp_danh_gia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `sp_image`
--
ALTER TABLE `sp_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT cho bảng `sp_loai`
--
ALTER TABLE `sp_loai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT cho bảng `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `tb_contact`
--
ALTER TABLE `tb_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT cho bảng `thuong_hieu`
--
ALTER TABLE `thuong_hieu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `yeu_thich`
--
ALTER TABLE `yeu_thich`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `don_hang`
--
ALTER TABLE `don_hang`
  ADD CONSTRAINT `don_hang_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tb_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  ADD CONSTRAINT `san_pham_ibfk_1` FOREIGN KEY (`id_th`) REFERENCES `thuong_hieu` (`id`),
  ADD CONSTRAINT `san_pham_ibfk_2` FOREIGN KEY (`id_dm`) REFERENCES `danh_muc` (`id`);

--
-- Các ràng buộc cho bảng `sp_danh_gia`
--
ALTER TABLE `sp_danh_gia`
  ADD CONSTRAINT `sp_danh_gia_ibfk_1` FOREIGN KEY (`id_sp`) REFERENCES `san_pham` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `sp_image`
--
ALTER TABLE `sp_image`
  ADD CONSTRAINT `sp_image_ibfk_1` FOREIGN KEY (`ma_sp`) REFERENCES `san_pham` (`ma_sp`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `sp_loai`
--
ALTER TABLE `sp_loai`
  ADD CONSTRAINT `san_phan_loai` FOREIGN KEY (`ma_sp`) REFERENCES `san_pham` (`ma_sp`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `yeu_thich`
--
ALTER TABLE `yeu_thich`
  ADD CONSTRAINT `yeu_thich_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tb_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
