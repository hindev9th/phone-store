<<<<<<< HEAD
Update**
-Thêm tb_Danh_gia trong database-
-Thêm đánh giá sản phẩm và hiển thị nội dung của người đã đánh giá-
-Thêm trang hiển thị ra danh sách sản phẩn (có phần trang,lọc sản phẩm theo tên,giá,nổi bật, tên hãng ,và danh mục)-
-Thêm phần tìm kiếm theo tên sp hoặc mã sp-
-Cập nhật lại thông tin sản phẩm khi lựa chon loại sản phẩm
-Cập nhật phần slider và banner có dẫn link-
-Sửa lại tb_sp-
*Admin
-còn nhiều lỗi
=======
Trang web đang trong quá trình xây dựng
>>>>>>> c8104dd68e4428ece20323273f9b75652ae61e3f
